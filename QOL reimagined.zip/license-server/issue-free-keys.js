require("dotenv").config();

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");

const secret = process.env.LICENSE_SIGNING_SECRET || "";
if (Buffer.byteLength(secret) < 32) {
  console.error("Set LICENSE_SIGNING_SECRET to a random value of at least 32 bytes first.");
  process.exit(1);
}

const outputPath = path.join(__dirname, "complimentary-keys.txt");
if (fs.existsSync(outputPath)) {
  console.error("Complimentary keys were already generated. Keep complimentary-keys.txt safe; remove it only if you intentionally need a new set.");
  process.exit(1);
}

function makeKey(source) {
  const payload = Buffer.from(JSON.stringify({
    version: 1,
    tier: "pro",
    source,
    id: crypto.randomBytes(12).toString("hex"),
    issuedAt: new Date().toISOString()
  })).toString("base64url");
  const signature = crypto.createHmac("sha256", secret).update(payload).digest("hex");
  return `MNT-PRO.${payload}.${signature}`;
}

const keys = [makeKey("owner-free"), makeKey("guest-1"), makeKey("guest-2")];
fs.writeFileSync(outputPath, keys.map((key, index) => `${index + 1}. ${key}`).join("\n") + "\n", { flag: "wx", mode: 0o600 });
console.log("Generated 3 complimentary keys: 1 owner key and 2 guest keys.");
console.log(`Keep this file private: ${outputPath}`);
