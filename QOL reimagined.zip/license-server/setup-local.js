const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");

const envPath = path.join(__dirname, ".env");
if (fs.existsSync(envPath)) {
  console.error(".env already exists. It was left unchanged.");
  process.exit(1);
}

const signingSecret = crypto.randomBytes(32).toString("hex");
const localConfiguration = [
  `LICENSE_SIGNING_SECRET=${signingSecret}`,
  "APP_BASE_URL=http://localhost:3001",
  "PORT=3001",
  ""
].join("\n");

try {
  fs.writeFileSync(envPath, localConfiguration, { flag: "wx", mode: 0o600 });
  console.log("Created a private local .env with a random signing secret.");
  console.log("Local server URL: http://localhost:3001");
  console.log("The signing secret was not printed. Keep .env private.");
} catch (error) {
  console.error(`Could not create .env: ${error.message}`);
  process.exit(1);
}
