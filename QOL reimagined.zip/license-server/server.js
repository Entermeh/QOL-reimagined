require("dotenv").config();

const crypto = require("node:crypto");
const express = require("express");
const Stripe = require("stripe");
const path = require("node:path");

const app = express();
const port = Number(process.env.PORT) || 3000;
const baseUrl = (process.env.APP_BASE_URL || `http://localhost:${port}`).replace(/\/$/, "");
const licenseSecret = process.env.LICENSE_SIGNING_SECRET || "";

app.use(express.json({ limit: "8kb" }));
app.use(express.static(path.join(__dirname, "public")));

function getStripe() {
  if (!process.env.STRIPE_SECRET_KEY) {
    const error = new Error("Stripe is not configured on the license server.");
    error.status = 503;
    throw error;
  }
  return new Stripe(process.env.STRIPE_SECRET_KEY);
}

function signLicense(source) {
  if (Buffer.byteLength(licenseSecret) < 32) {
    const error = new Error("LICENSE_SIGNING_SECRET must be at least 32 bytes.");
    error.status = 503;
    throw error;
  }

  const payload = Buffer.from(JSON.stringify({
    version: 1,
    tier: "pro",
    source,
    id: crypto.randomBytes(12).toString("hex"),
    issuedAt: new Date().toISOString()
  })).toString("base64url");
  const signature = crypto.createHmac("sha256", licenseSecret).update(payload).digest("hex");
  return `MNT-PRO.${payload}.${signature}`;
}

function isValidLicense(licenseKey) {
  if (typeof licenseKey !== "string") return false;
  const match = /^MNT-PRO\.([A-Za-z0-9_-]+)\.([a-f0-9]{64})$/.exec(licenseKey.trim());
  if (!match || Buffer.byteLength(licenseSecret) < 32) return false;

  const expected = crypto.createHmac("sha256", licenseSecret).update(match[1]).digest();
  const actual = Buffer.from(match[2], "hex");
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) return false;

  try {
    const payload = JSON.parse(Buffer.from(match[1], "base64url").toString("utf8"));
    return payload.version === 1 && payload.tier === "pro" && typeof payload.id === "string";
  } catch {
    return false;
  }
}

app.get("/api/health", (_request, response) => {
  response.json({
    ok: true,
    stripeConfigured: Boolean(process.env.STRIPE_SECRET_KEY),
    licenseSigningConfigured: Buffer.byteLength(licenseSecret) >= 32
  });
});

app.post("/api/checkout", async (_request, response) => {
  try {
    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{
        price_data: {
          currency: "gbp",
          unit_amount: 200,
          product_data: { name: "Mini NetTool Pro" }
        },
        quantity: 1
      }],
      success_url: `${baseUrl}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/cancel.html`
    });
    response.json({ checkoutUrl: session.url });
  } catch (error) {
    response.status(error.status || 500).json({ error: error.message || "Could not create a checkout session." });
  }
});

app.post("/api/redeem", async (request, response) => {
  const sessionId = request.body && request.body.sessionId;
  if (typeof sessionId !== "string" || !/^cs_(test|live)_[A-Za-z0-9]+$/.test(sessionId)) {
    return response.status(400).json({ error: "Invalid checkout session." });
  }

  try {
    const stripe = getStripe();
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    if (session.payment_status !== "paid" || session.mode !== "payment" || session.currency !== "gbp" || session.amount_total !== 200) {
      return response.status(402).json({ error: "Stripe has not confirmed a £2 payment for Pro." });
    }

    let licenseKey = session.metadata && session.metadata.proLicenseKey;
    if (!licenseKey || !isValidLicense(licenseKey)) {
      licenseKey = signLicense("stripe");
      await stripe.checkout.sessions.update(sessionId, {
        metadata: { ...session.metadata, proLicenseKey: licenseKey }
      });
    }
    return response.json({ licenseKey });
  } catch (error) {
    return response.status(error.status || 500).json({ error: error.message || "Could not issue the Pro key." });
  }
});

app.post("/api/activate", (request, response) => {
  const licenseKey = request.body && request.body.licenseKey;
  if (!isValidLicense(licenseKey)) {
    return response.status(403).json({ active: false, error: "This Pro key is invalid." });
  }
  return response.json({ active: true, tier: "pro" });
});

app.get("/cancel.html", (_request, response) => {
  response.type("html").send("<!doctype html><meta charset=\"utf-8\"><title>Checkout cancelled</title><h1>Checkout cancelled</h1><p>No payment was taken.</p>");
});

app.listen(port, () => {
  console.log(`Mini NetTool license server listening on port ${port}`);
});
