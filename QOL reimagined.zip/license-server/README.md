# Mini NetTool Pro license server

This service creates Stripe Checkout sessions for a one-time £2 Pro purchase, confirms completed payments with Stripe, and returns signed license keys. Stripe's private key and the license signing secret stay on this server.

## Configure locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Set `STRIPE_SECRET_KEY` from your Stripe dashboard. Start with a Stripe test key while testing.
4. Generate a signing secret with `node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"` and set it as `LICENSE_SIGNING_SECRET`.
5. Set `APP_BASE_URL` to this service's public HTTPS address. For local testing, keep `http://localhost:3000`.
6. Run `npm install`, then `npm start`.

The `/api/health` route reports whether the required configuration is present without exposing secrets. Use Stripe test mode first; configure a live key only after testing.

## Complimentary keys

Run `npm run issue:free` once using the same `LICENSE_SIGNING_SECRET` as the deployed service. It writes one owner key and two guest keys to `complimentary-keys.txt`. The file is ignored by Git; keep it private and give one key to each person. The command refuses to overwrite an existing set.

## Deploy

Deploy this folder as a Node web service on a host that supports HTTPS. Set the start command to `npm start`, then configure `STRIPE_SECRET_KEY`, `LICENSE_SIGNING_SECRET`, and `APP_BASE_URL` as private environment variables on the host. Do not commit or send secret values. Keep the same signing secret after deployment or previously issued keys will stop validating.

Set `MINITOOL_LICENSE_SERVER` on each desktop to the service's HTTPS base URL. The desktop app then calls `/api/checkout` and `/api/activate`.
