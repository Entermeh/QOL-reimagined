import shutil
from pathlib import Path
import math

try:
    from PIL import Image, ImageDraw
except ImportError:
    raise SystemExit('Pillow is required. Install with: pip install pillow')

root = Path('c:/Users/vin/Desktop/multitool/ranodm batch files/exes')
icons = root / 'icons'
icons.mkdir(exist_ok=True)

cat_src = root / 'cat.png'
if cat_src.exists():
    shutil.copy2(cat_src, icons / 'cat.png')

W = H = 512
img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
cx, cy = W / 2, H / 2
r = 200
teeth = 12

for i in range(teeth * 2):
    ang = i * (360 / (teeth * 2))
    p1 = (cx + (r - 20) * math.cos(math.radians(ang - 10)), cy + (r - 20) * math.sin(math.radians(ang - 10)))
    p2 = (cx + (r + 35) * math.cos(math.radians(ang - 6)), cy + (r + 35) * math.sin(math.radians(ang - 6)))
    p3 = (cx + (r + 35) * math.cos(math.radians(ang + 6)), cy + (r + 35) * math.sin(math.radians(ang + 6)))
    p4 = (cx + (r - 20) * math.cos(math.radians(ang + 10)), cy + (r - 20) * math.sin(math.radians(ang + 10)))
    d.polygon([p1, p2, p3, p4], fill=(0, 0, 0, 255))

# Gear body
for radius in (r, 110):
    d.ellipse((cx - radius, cy - radius, cx + radius, cy + radius), fill=(0, 0, 0, 255))

# Center hole
center_radius = 65
# Cut the hole by drawing transparent center
mask = Image.new('RGBA', (W, H), (0, 0, 0, 0))
md = ImageDraw.Draw(mask)
md.ellipse((cx - center_radius, cy - center_radius, cx + center_radius, cy + center_radius), fill=(0, 0, 0, 255))
img = Image.alpha_composite(img, Image.new('RGBA', (W, H), (0, 0, 0, 0)))
# simpler approach: transparent non-hole is not easy with alpha composite, so use final filled gear with inner center black
img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
for i in range(teeth * 2):
    ang = i * (360 / (teeth * 2))
    p1 = (cx + (r - 20) * math.cos(math.radians(ang - 10)), cy + (r - 20) * math.sin(math.radians(ang - 10)))
    p2 = (cx + (r + 35) * math.cos(math.radians(ang - 6)), cy + (r + 35) * math.sin(math.radians(ang - 6)))
    p3 = (cx + (r + 35) * math.cos(math.radians(ang + 6)), cy + (r + 35) * math.sin(math.radians(ang + 6)))
    p4 = (cx + (r - 20) * math.cos(math.radians(ang + 10)), cy + (r - 20) * math.sin(math.radians(ang + 10)))
    d.polygon([p1, p2, p3, p4], fill=(0, 0, 0, 255))
d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(0, 0, 0, 255))
d.ellipse((cx - 110, cy - 110, cx + 110, cy + 110), fill=(0, 0, 0, 255))
d.ellipse((cx - 65, cy - 65, cx + 65, cy + 65), fill=(255, 255, 255, 0))

img.save(icons / 'gear.png')
# Save a basic ICO version too
img.save(icons / 'icon.ico')

print('Created:', sorted(p.name for p in icons.iterdir()))
